package com.example.ingeniumeducationassisgment.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ingeniumeducationassisgment.Model.UserDto;
import com.example.ingeniumeducationassisgment.R;

import java.util.List;

public class UserlistAdapter extends RecyclerView.Adapter<UserlistAdapter.ViewHolder> {

    private Context context;
    private List<UserDto> userDtos;

    public UserlistAdapter(Context context, List<UserDto> userDtos) {
        this.context = context;
        this.userDtos = userDtos;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.useritemlist, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // bind the data
        holder.mEmployeeName.setText(userDtos.get(position).getEmployee_name());
        holder.mEmployeeAge.setText(userDtos.get(position).getEmployee_age());
        holder.mEmployeeSalary.setText(userDtos.get(position).getEmployee_salary());
        holder.profileImage.setImageResource(R.drawable.ic_person_black_24dp);
        holder.id.setText(userDtos.get(position).getId());


    }

    @Override
    public int getItemCount() {
        return userDtos.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mEmployeeName, mEmployeeAge, mEmployeeSalary, id;
        ImageView profileImage;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            mEmployeeName = itemView.findViewById(R.id.employeeName);
            mEmployeeSalary = itemView.findViewById(R.id.employeeSalary);
            mEmployeeAge = itemView.findViewById(R.id.employeeAge);
            id = itemView.findViewById(R.id.id);
            profileImage = itemView.findViewById(R.id.profile);


        }
    }

}
