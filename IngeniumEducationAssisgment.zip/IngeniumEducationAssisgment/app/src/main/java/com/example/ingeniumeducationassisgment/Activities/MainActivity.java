package com.example.ingeniumeducationassisgment.Activities;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ingeniumeducationassisgment.Adapter.UserlistAdapter;
import com.example.ingeniumeducationassisgment.ApiInterface.PostDataKey;
import com.example.ingeniumeducationassisgment.Model.UserDto;
import com.example.ingeniumeducationassisgment.R;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private List<UserDto> userDtoList;
    private final String JSON_URL = "http://dummy.restapiexample.com/api/v1/employees";
    private UserlistAdapter userlistAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Init();
    }



 //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Main methode @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

    private void Init(){
        recyclerView = findViewById(R.id.recycler_productList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);
        userDtoList = new ArrayList<>();
        GetUserListData();

    }


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Get UserList (11-July-2020) @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

    private void GetUserListData() {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, JSON_URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                Log.d("code", response.toString());
                try {
                    JSONObject jsonObject =new JSONObject(response.toString());
                    JSONArray array = jsonObject.getJSONArray("data");
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject uselistJsonObject = array.getJSONObject(i);
                        UserDto userDto = new UserDto();
                        userDto.setId(uselistJsonObject.getString(PostDataKey.Employee_Id));
                        userDto.setEmployee_name(uselistJsonObject.getString(PostDataKey.Employee_name));
                        userDto.setEmployee_age(uselistJsonObject.getString(PostDataKey.Employee_age));
                        userDto.setEmployee_salary(uselistJsonObject.getString(PostDataKey.Employee_salary));
                        Log.d("code", uselistJsonObject.toString());
                        userDtoList.add(userDto);

                    }
                    userlistAdapter = new UserlistAdapter(getApplicationContext(), userDtoList);
                    recyclerView.setAdapter(userlistAdapter);


                } catch (JSONException e) {
                    e.printStackTrace();

                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {


                    }

                    ;

                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonObjectRequest);
    }


//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ End Api Methode @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@2@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@



}


