package com.example.ingeniumeducationassisgment.ApiInterface;

public class PostDataKey {

    public static final String Employee_name ="employee_name" ;
    public static final String Employee_age="employee_age" ;
    public static final String Employee_salary ="employee_salary" ;
    public static final String Employee_Id ="id" ;
}
